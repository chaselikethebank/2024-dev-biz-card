# 2024-dev-biz-card

biz card for devs using tailwind 

deployment for dev
https://chaselikethebank.github.io/2024-dev-biz-card/